const { postValidator, getValidator } = require('../validator/swap');
const { postController, getController } = require('../controller/swap');
const response = require('../service/response');
const warmup = require('../service/warmup');

exports.post = (event, context, callback) => __async(function*(){
  warmup(event, callback);
  const { err, params } = yield postValidator(event);
  if (!err) {
    postController(params, callback);
  } else {
    callback(null, response({ err }, 400))
  }
}())

exports.get = (event, context, callback) => __async(function*(){
  warmup(event, callback);
  const { err, params } = yield getValidator(event);
  if (!err) {
    getController(params, callback);
  } else {
    callback(null, response({ err }, 400))
  }
}())

function __async(g){return new Promise(function(s,j){function c(a,x){try{var r=g[x?"throw":"next"](a)}catch(e){j(e);return}r.done?s(r.value):Promise.resolve(r.value).then(c,d)}function d(e){c(e,1)}c()})}
