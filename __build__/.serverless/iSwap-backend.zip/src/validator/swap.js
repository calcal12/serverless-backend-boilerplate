const moment = require('moment');
const { verifyToken } = require('../service/auth');

const postValidator = (event) => __async(function*(){
  const body = JSON.parse(event.body);
  let err;
  try {
    const id = yield verifyToken(event.headers.Authorization);
    params.user_id = id;
    // if (typeof body.username !== 'string') {
    //   err = 'Please enter username';
    // } else if (typeof body.password !== 'string') {
    //   err = 'Please enter password';
    // }
  } catch(error) {
    err = error
  }

  const params = {

  };
  return { err, params }
}())

const getValidator = (event) => __async(function*(){
  let err;
  const params = {}
  try {
    const id = yield verifyToken(event.headers.Authorization);
    params.user_id = id;
  } catch(error) {
    err = error
  }

  return { err, params }
}())

module.exports = {
  postValidator,
  getValidator
}

function __async(g){return new Promise(function(s,j){function c(a,x){try{var r=g[x?"throw":"next"](a)}catch(e){j(e);return}r.done?s(r.value):Promise.resolve(r.value).then(c,d)}function d(e){c(e,1)}c()})}
